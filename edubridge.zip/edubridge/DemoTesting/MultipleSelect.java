package com.edubridge.DemoTesting;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

/**
 * @author Shubhangi
 *
 */
public class MultipleSelect {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse over to element
		action.moveToElement(TesterHub).build().perform();
		
		//mouse over to demo testing site
		WebElement DemoTsting = driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[1]/a[1]/span[1]"));
		action.moveToElement(DemoTsting).build().perform();
		
		//click on select element
		driver.findElement(By.xpath("//span[contains(text(),'Select Elements')]")).click();
		
		WebElement iframe2= driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/p[1]/iframe[1]"));
		driver.switchTo().frame(iframe2);
		System.out.println("switch to iframe");
		
		Actions builder = new Actions(driver);
		WebElement select = driver.findElement(By.id("selectable"));
		List<WebElement> options = select.findElements(By.tagName("li"));
		
		System.out.println(options.size());
		
		builder.keyDown(Keys.CONTROL).click(options.get(2)).click(options.get(4)).click(options.get(6)).build().perform();
	     
	
	}

}

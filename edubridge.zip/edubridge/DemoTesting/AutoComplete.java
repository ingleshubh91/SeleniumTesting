package com.edubridge.DemoTesting;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Shubhangi
 *
 */
public class AutoComplete {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse hover to element
		action.moveToElement(TesterHub).build().perform();
		
		//mouse hover to demo testing site
		WebElement DemoTsting = driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[1]/a[1]/span[1]"));
		action.moveToElement(DemoTsting).build().perform();
		
		//click on auto complete
		driver.findElement(By.xpath("//span[contains(text(),'Auto Complete')]")).click();
		
		//click on categories
		driver.findElement(By.id("Categories")).click();
		System.out.println("Categories clicked");
		
		//Switch to Frame using xpath of the frame
		WebElement iframe = driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/p[1]/iframe[1]"));
        
		driver.switchTo().frame(iframe);
        System.out.println("********We are switch to the iframe*******");
        
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		
		//write text in search
		driver.findElement(By.id("search")).sendKeys("a");
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("ui-id-1")));
		
		//list of autocomplete menu
		List<WebElement> list = driver.findElements(By.id("ui-id-1"));
		
		System.out.println("Auto Suggest List: " + list.size());
			
			for (WebElement a : list)
	        {
	        	System.out.println("Values are = " + a.getText());
	        	if (a.getText().equalsIgnoreCase("annk K12"));
	        	a.click();
	        	//Thread.sleep(3000);
	        	break;
	        }
		
		// swith to default page
		driver.switchTo().defaultContent();	
		
		//click on comboBox
		driver.findElement(By.id("ComboBox")).click();
		System.out.println("ComboBox clicked");
		
		WebElement iframe1 = driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p[1]/iframe[1]"));
		driver.switchTo().frame(iframe1);
		System.out.println("********We are switch to the iframe*******");
		
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		
		//click on button
		driver.findElement(By.xpath("//button[@id='toggle']")).click();
		
		Select select =new Select(driver.findElement(By.id("combobox")));
		select.selectByVisibleText("Java");
		System.out.println("Java is selected");
		
	}

}

package com.edubridge.DemoTesting;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * @author Shubhangi
 *
 */
public class FramesAndWindows {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse over to element
		action.moveToElement(TesterHub).build().perform();
		
		//mouse over to demo testing site
		WebElement DemoTsting = driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[1]/a[1]/span[1]"));
		action.moveToElement(DemoTsting).build().perform();
		
		//click on Frames and windows
		driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[1]/div[1]/ul[1]/li[13]/a[1]/span[1]")).click();
		
		//click on button click here
		driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[1]")).click();
		
		String Mainwindow = driver.getWindowHandle();
		
		// To handle all new opened window
		Set<String> s1 =driver.getWindowHandles();
		
		Iterator<String> itr = s1.iterator();
		
		while(itr.hasNext())
		{
			String ChildWindow = itr.next();
			if(!Mainwindow.equalsIgnoreCase(ChildWindow))
			{
				driver.switchTo().window(ChildWindow);
				driver.close();
				System.out.println("window closed");
				
			}
		}
		// Switching to Parent window i.e Main Window.
		driver.switchTo().window(Mainwindow);
		System.out.println("Back to main window");
	}

}

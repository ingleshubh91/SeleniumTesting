package com.edubridge.samplepage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

/**
 * @author Shubhangi
 *
 */
public class SamplePage {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse over to element
		action.moveToElement(TesterHub).build().perform();
		
		//click on sample page
		driver.findElement(By.xpath("//span[contains(text(),'Sample Page Test')]")).click();
		
		//Upload photo
		driver.findElement(By.name("file-553")).sendKeys("C:\\Users\\Shubhangi\\Downloads\\download (2).jpg");
		System.out.println("Photo uploaded");
		
		driver.findElement(By.id("g2599-name")).sendKeys("Shubhangi");
		driver.findElement(By.id("g2599-email")).sendKeys("shubh@gmail.com");
		driver.findElement(By.id("g2599-website")).sendKeys("www.shubhangi.com");
		
		//Dropdown List
		Select drplist =new Select(driver.findElement(By.id("g2599-experienceinyears")));
		drplist.selectByVisibleText("3-5");
		
		//checkboxes
		driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[2]/form[1]/div[5]/label[2]/input[1]")).click();
		driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[2]/form[1]/div[5]/label[3]/input[1]")).click();
		driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[2]/div[2]/form[1]/div[5]/label[4]/input[1]")).click();
	
		//radio buttons
		driver.findElement(By.xpath("//*[@id=\"contact-form-2599\"]/form/div[6]/label[2]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"contact-form-2599\"]/form/div[6]/label[3]/input")).click();
		
		//Alert button
		driver.findElement(By.xpath("//button[contains(text(),'Alert Box : Click Here')]")).click();
		Alert alert = driver.switchTo().alert();
		System.out.println("Text is:" +alert.getText());
		alert.dismiss();
		alert.accept();
		
		driver.findElement(By.id("contact-form-comment-g2599-comment")).sendKeys("This is demo project");
		//submit button
		driver.findElement(By.xpath("//button[contains(text(),'Submit')]")).submit();
		
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		
		//scroll up
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -2000)");
		//Thread.sleep(3000);
		System.out.println("Scroll Up");
		
		//click on go back
		driver.findElement(By.xpath("//a[contains(text(),'go back')]")).click();
	}

}

package com.edubridge.globalSQA;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DataScienceCS {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		
		//open cheetsheet tab
		driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[2]/a[1]")).click();
		
		// click on Data Science Cheat Sheet
		 //Thread.sleep(2000);
		 driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		 driver.findElement(By.xpath("//a[contains(text(),'Data Science Cheat Sheet')]")).click();
		 
		 String Mainwindow = driver.getWindowHandle();
			
			// To handle all new opened window
			Set<String> s1 =driver.getWindowHandles();
			
			Iterator<String> itr = s1.iterator();
			
			while(itr.hasNext())
			{
				String ChildWindow = itr.next();
				if(!Mainwindow.equalsIgnoreCase(ChildWindow))
				{
					driver.switchTo().window(ChildWindow);
					
					driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/a[2]")).click();
					driver.findElement(By.xpath("//body/div[@id='wrapper']/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]")).click();
					System.out.println("arrow Clicked");
					driver.findElement(By.xpath("//a[contains(text(),'Download')]")).click();
					driver.close();
					System.out.println("window closed");
					
				}
			}
			// Switching to Parent window i.e Main Window.
			driver.switchTo().window(Mainwindow);
	}

}

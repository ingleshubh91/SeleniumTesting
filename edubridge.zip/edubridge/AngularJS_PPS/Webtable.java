package com.edubridge.AngularJS_PPS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * @author Shubhangi
 *
 */
public class Webtable {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse over to element
		action.moveToElement(TesterHub).build().perform();
		
		//mouse over to angularJS..
		WebElement angularjS= driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[2]/a[1]/span[1]"));
		action.moveToElement(angularjS).build().perform();
		
		//click on web table
		driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[2]/div[1]/ul[1]/li[4]/a[1]")).click();
		
		driver.findElement(By.xpath("//thead/tr[2]/th[1]/input[1]")).sendKeys("pol");
		driver.findElement(By.xpath("//thead/tr[2]/th[2]/input[1]")).sendKeys("80");
	}

}

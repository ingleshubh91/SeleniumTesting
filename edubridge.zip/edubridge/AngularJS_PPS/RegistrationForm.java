package com.edubridge.AngularJS_PPS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * @author Shubhangi
 *
 */
public class RegistrationForm {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver\\Chrome Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//open webpage
		driver.get("https://www.globalsqa.com/");
		driver.manage().window().maximize();
		//TesterHub web Element
		WebElement TesterHub = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/a[1]"));
		
		Actions action = new Actions(driver);
		//mouse over to element
		action.moveToElement(TesterHub).build().perform();
		
		//mouse over to angularJS..
		WebElement angularjS= driver.findElement(By.xpath("//body[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[4]/div[1]/ul[1]/li[2]/a[1]/span[1]"));
		action.moveToElement(angularjS).build().perform();
		
		driver.findElement(By.xpath("//span[contains(text(),'Registration Form')]")).click();
		
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
		//driver.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
		//driver.findElement(By.linkText("Register")).click();
		driver.findElement(By.id("username")).sendKeys("shubh");
		driver.findElement(By.id("password")).sendKeys("shubh123");
	}

}
